package com.mycompany.myapp4;

import android.app.*;
import android.os.*;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.*;
import android.content.*;
import android.net.*;

public class MainActivity extends AppCompatActivity 
implements ForceUpdateChecker.OnUpdateNeededListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ForceUpdateChecker.with(this).onUpdateNeeded(this).check();
    }

    @Override
    public void onUpdateNeeded(final String updateUrl) {
        AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle("New version available")
			.setMessage("Please, update app to new version to continue reposting.")
			.setPositiveButton("Update",
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					redirectStore(updateUrl);
				}
			}).setNegativeButton("No, thanks",
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			}).create();
        dialog.show();
    }

    private void redirectStore(String updateUrl) {
        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
